#lets first import all the required libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
#lets load the data now
data=pd.read_csv(
    "u.data",# "u.data" is the file name
    
    sep="\t",#this file in movielens is seperated by tabs
    
    
    names=["user_id","item_id","rating","timestamp"]#these are thr rows user_id,item_id,rating,timestamp
)
#delete timestamp column because it is not required
data=data.drop(columns=["timestamp"])

global_mean=data["rating"].mean()# its global mean because we are not using group by
#user-average ratings

user_mean=data.groupby("user_id")["rating"].mean()


data[user_mean]=data["user_id"].map(user_mean)
#item-average rating
item_mean=data.groupby("item_id")["rating"].mean()

data["item_mean"]=data["item_id"].map(item_mean)

#item rating count
item_count=data.groupby("item_id")["rating"].count()
data["item_count"]=data["item_id"].map(item_count)

#user rating count
user_count=data.groupby("user_id")["rating"].count()
data["user_count"]=data["user_id"].map(user_count)

#user bias
data["user_bias"]=data["user_mean"]-global_mean;
#item bias
data["item_bias"]=data["item_mean"]-global_mean;
 #now mean ratings,rating counts and biases are done now we will do labeeling encoding and 5-fold cross validation which is the main part
 #lets first do encoding
user_label=LabelEncoder()

item_label=LabelEncoder()

data["user_id"]=user_label.fit_transform(data["user_id"])

data["item_id"]=item_label.fit_transform(data["item_id"])
#labelling converts categorical values into numerical values
#now we will remove rating column from x and store it in y
X=data.drop(columns=["rating"])


y=data["rating"]
#5-fold cross validation
k_f=KFold(n_splits=5,shuffle=True,random_state=42)# each split,4 partstrainign 1 part testing so each part becomes testing ones
#now we have to store results
accuracy_fold=[];#in this we will store accuracy of each fold
no_fold=1;#this is just to track

for train_index,test_index in kf.split(X):
    #split the data
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    
    
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    
    #the model
    model=RandomForestClassifier(
        no_estimators=200,#build 200 trees
        
        depth_max=20,#depth
        
        random_state=42,#randomness
        
        n_jobs=-1;
    )
    model.fit(X_train,y_train)# train the classifier
    pred_y=model.predict(y_test)#test te=he classifier
    accuracy=accuracy_score(y_test,pred_y)
    accuracy_fold.append(accuracy)
    no_fold+=1;
for i,acc in enumerate(accuracy_fold):
    print(f"fold {i+1}:{acc:4f}")
    






